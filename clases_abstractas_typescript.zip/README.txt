Guía resuelta: Clases abstractas en TypeScript

Archivos incluidos:
- ejercicio1_animales.ts
- ejercicio2_vehiculos.ts
- ejercicio3_figuras.ts
- ejercicio4_empleados.ts
- ejercicio5_pagos.ts
- ejercicio6_notificaciones.ts
- ejercicio7_transporte.ts
- ejercicio8_tienda.ts

Cómo ejecutarlos:
1. Instala Node.js
2. Instala TypeScript y ts-node:
   npm install -g typescript ts-node
3. Ejecuta un archivo:
   ts-node ejercicio1_animales.ts

Todos los ejercicios usan readline y siguen la guía de clases abstractas.
